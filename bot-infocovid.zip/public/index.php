<?php
require __DIR__ . '/../vendor/autoload.php';

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Slim\Factory\AppFactory;

use \LINE\LINEBot;
use \LINE\LINEBot\HTTPClient\CurlHTTPClient;
use \LINE\LINEBot\MessageBuilder\MultiMessageBuilder;
use \LINE\LINEBot\MessageBuilder\TextMessageBuilder;
use \LINE\LINEBot\MessageBuilder\StickerMessageBuilder;
use \LINE\LINEBot\SignatureValidator as SignatureValidator;

$pass_signature = true;

// set LINE channel_access_token and channel_secret
$channel_access_token = "+w1IqMX5IMmxmGvT1qZxuWZ6B1XIg4+r3QzQ0aCzhe8lXEx6stw3LpqZXvxy3fUa25LG0PxfaYHzFZvh2fbqvdTjqO02YygMG8ZrxRwBuezE4TtfHGoIKd/MFaNrpG6m3/iOx3SgfeoaMDaEu7exuQdB04t89/1O/w1cDnyilFU=";
$channel_secret = "ac3f9a7978e2583b4feebd8153675e0a";

// inisiasi objek bot
$httpClient = new CurlHTTPClient($channel_access_token);
$bot = new LINEBot($httpClient, ['channelSecret' => $channel_secret]);

$app = AppFactory::create();
$app->setBasePath("/public");

$app->get('/', function (Request $request, Response $response, $args) {
    $response->getBody()->write("Hello World!");
    return $response;
});

// buat route untuk webhook
$app->post('/webhook', function (Request $request, Response $response) use ($channel_secret, $bot, $httpClient, $pass_signature) {
    // get request body and line signature header
    $body = $request->getBody();
    $signature = $request->getHeaderLine('HTTP_X_LINE_SIGNATURE');

    // log body and signature
    file_put_contents('php://stderr', 'Body: ' . $body);

    if ($pass_signature === false) {
        // is LINE_SIGNATURE exists in request header?
        if (empty($signature)) {
            return $response->withStatus(400, 'Signature not set');
        }

        // is this request comes from LINE?
        if (!SignatureValidator::validateSignature($body, $channel_secret, $signature)) {
            return $response->withStatus(400, 'Invalid signature');
        }
    }

    // kode aplikasi nanti disini
    $data = json_decode($body, true);
    if (is_array($data['events'])) {
        foreach ($data['events'] as $event) {
            if ($event['type'] == 'message') {
                if ($event['message']['type'] == 'text') {
                    if ($event['message']['text'] == '!covid') {
                        $flexTemplate = file_get_contents("../flex_menu.json"); // template flex message
                        $result = $httpClient->post(LINEBot::DEFAULT_ENDPOINT_BASE . '/v2/bot/message/reply', [
                            'replyToken' => $event['replyToken'],
                            'messages'   => [
                                [
                                    'type'     => 'flex',
                                    'altText'  => 'Test Flex Message',
                                    'contents' => json_decode($flexTemplate)
                                ]
                            ],
                        ]);
                    } else {
                        $textMessageBuilder1 = new TextMessageBuilder('Silahkan gunakan command !covid untuk menampilkan menu1');
                        $stickerMessageBuilder = new StickerMessageBuilder(1, 106);

                        $multiMessageBuilder = new MultiMessageBuilder();
                        $multiMessageBuilder->add($textMessageBuilder1);
                        $multiMessageBuilder->add($stickerMessageBuilder);
                        $result = $bot->replyMessage($event['replyToken'], $multiMessageBuilder);
                    }
                }
            } else if ($event['type'] == 'postback') {
                if ($event['postback']['data'] == 'data=indonesia') {
                    $data = [
                        'lokasi' => 'indonesia'
                    ];
                    $text = data_covid($data);
                    $result = $bot->replyText($event['replyToken'], $text);
                } else if ($event['postback']['data'] == 'data=provinsi') {
                    $flexTemplate = file_get_contents("../flex_menu_provinsi.json"); // template flex message
                    $result = $httpClient->post(LINEBot::DEFAULT_ENDPOINT_BASE . '/v2/bot/message/reply', [
                        'replyToken' => $event['replyToken'],
                        'messages'   => [
                            [
                                'type'     => 'flex',
                                'altText'  => 'Test Flex Message',
                                'contents' => json_decode($flexTemplate)
                            ]
                        ],
                    ]);
                } else if ($event['postback']['data'] == 'data=kabupatenkota') {
                    $flexTemplate = file_get_contents("../flex_menu_kabkota.json"); // template flex message
                    $result = $httpClient->post(LINEBot::DEFAULT_ENDPOINT_BASE . '/v2/bot/message/reply', [
                        'replyToken' => $event['replyToken'],
                        'messages'   => [
                            [
                                'type'     => 'flex',
                                'altText'  => 'Test Flex Message',
                                'contents' => json_decode($flexTemplate)
                            ]
                        ],
                    ]);
                } else if ($event['postback']['data'] == 'data=prov_jawa_tengah') {
                    $data = [
                        'lokasi' => 'jawa_tengah'
                    ];
                    $data_covid = data_covid($data);
                    $nama_provinsi = $data_covid['nama_provinsi'];
                    $positif = $data_covid['positif'];
                    $sembuh = "2";
                    $meninggal = "3";
                    $flexTemplate = [
                        "type" => "bubble",
                        "header" => [
                            "type" => "box",
                            "layout" => "vertical",
                            "contents" => [
                                [
                                    "type" => "text",
                                    "text" => $nama_provinsi,
                                    "weight" => "bold",
                                    "size" => "xl",
                                    "color" => "#FFFFFF"
                                ]
                            ],
                            "backgroundColor" => "#007bff"
                        ],
                        "body" => [
                            "type" => "box",
                            "layout" => "vertical",
                            "contents" => [
                                [
                                    "type" => "box",
                                    "layout" => "horizontal",
                                    "contents" => [
                                        [
                                            "type" => "text",
                                            "text" => "Positif"
                                        ],
                                        [
                                            "type" => "text",
                                            "text" => $positif
                                        ]
                                    ]
                                ],
                                [
                                    "type" => "box",
                                    "layout" => "horizontal",
                                    "contents" => [
                                        [
                                            "type" => "text",
                                            "text" => "Sembuh"
                                        ],
                                        [
                                            "type" => "text",
                                            "text" => $sembuh
                                        ]
                                    ]
                                ],
                                [
                                    "type" => "box",
                                    "layout" => "horizontal",
                                    "contents" => [
                                        [
                                            "type" => "text",
                                            "text" => "Meninggal"
                                        ],
                                        [
                                            "type" => "text",
                                            "text" => $meninggal
                                        ]
                                    ]
                                ]
                            ]
                        ]
                    ];
                    $result = $httpClient->post(LINEBot::DEFAULT_ENDPOINT_BASE . '/v2/bot/message/reply', [
                        'replyToken' => $event['replyToken'],
                        'messages'   => [
                            [
                                'type'     => 'flex',
                                'altText'  => 'Test Flex Message',
                                'contents' => $flexTemplate
                            ]
                        ],
                    ]);
                } else if ($event['postback']['data'] == 'data=kab_kudus') {
                    $data = [
                        'lokasi' => 'kudus'
                    ];
                    $text = data_covid($data);
                    $result = $bot->replyText($event['replyToken'], $text);
                }
            }
            $response->getBody()->write($result->getJSONDecodedBody());
            return $response
                ->withHeader('Content-Type', 'application/json')
                ->withStatus($result->getHTTPStatus());
        }
    }
});
$app->get('/profile', function ($req, $response) use ($bot) {
    $data = [
        'lokasi' => 'jawa_tengah'
    ];
    $response->getBody()->write(json_encode(data_covid($data)));
    return $response
        ->withHeader('Content-Type', 'text/html');
});
$app->run();

function data_covid($data)
{
    $url = 'https://api.ddg.my.id/covid19/indonesia.php';
    $ch = curl_init();
    $timeout = 5;

    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);

    // Get URL content
    $json_data = curl_exec($ch);
    // close handle to release resources
    curl_close($ch);
    $json_de_data = json_decode($json_data);

    if ($data['lokasi'] == 'indonesia') {
        $text = "Indonesia\n
    Positif : " . $json_de_data->indonesia->positif . "\n
    Sembuh : " . $json_de_data->indonesia->sembuh . "\n
    Meninggal : " . $json_de_data->indonesia->meninggal . "\n
    Dirawat : " . $json_de_data->indonesia->dirawat;
        return $text;
    } else if ($data['lokasi'] == 'jawa_tengah') {
        //     $text = "Jawa Tengah\n
        // Positif : " . $json_de_data->jawa_tengah->positif . "\n
        // Sembuh : " . $json_de_data->jawa_tengah->sembuh . "\n
        // Meninggal : " . $json_de_data->jawa_tengah->meninggal;
        $data_jateng = [
            'nama_provinsi' => 'Jawa Tengah',
            'positif' => 13,
            'sembuh' => $json_de_data->jawa_tengah->sembuh,
            'meninggal' => $json_de_data->jawa_tengah->meninggal
        ];
        return $data_jateng;
    } else if ($data['lokasi'] == 'kudus') {
        $text = "Kudus\n
    Positif : " . $json_de_data->kudus->positif . "\n
    Sembuh : " . $json_de_data->kudus->sembuh . "\n
    Meninggal : " . $json_de_data->kudus->meninggal . "\n
    Dirawat : " . $json_de_data->kudus->dirawat;
        return $text;
    }
}
