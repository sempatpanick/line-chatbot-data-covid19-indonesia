<?php
    $data = [
        "type"=> "bubble",
        "header"=> [
            "type"=> "box",
            "layout"=> "vertical",
            "contents"=> [
                [
                    "type"=> "text",
                    "text"=> $nama_provinsi,
                    "weight"=> "bold",
                    "size"=> "xl",
                    "color"=> "#FFFFFF"
                ]
            ],
            "backgroundColor"=> "#007bff"
        ],
        "body"=> [
            "type"=> "box",
            "layout"=> "vertical",
            "contents"=> [
                [
                    "type"=> "box",
                    "layout"=> "horizontal",
                    "contents"=> [
                        [
                            "type"=> "text",
                            "text"=> "Positif"
                        ],
                        [
                            "type"=> "text",
                            "text"=> $positif
                        ]
                    ]
                ],
                [
                    "type"=> "box",
                    "layout"=> "horizontal",
                    "contents"=> [
                        [
                            "type"=> "text",
                            "text"=> "Sembuh"
                        ],
                        [
                            "type"=> "text",
                            "text"=> $sembuh
                        ]
                    ]
                ],
                [
                    "type"=> "box",
                    "layout"=> "horizontal",
                    "contents"=> [
                        [
                            "type"=> "text",
                            "text"=> "Meninggal"
                        ],
                        [
                            "type"=> "text",
                            "text"=> $meninggal
                        ]
                    ]
                ]
            ]
        ]
    ];